DROP TABLE order_info PURGE;

DROP TABLE reservation PURGE;

DROP TABLE item PURGE;

DROP TABLE customer PURGE;

DROP TABLE address PURGE;
